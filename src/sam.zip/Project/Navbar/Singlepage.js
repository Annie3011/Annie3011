import axios from 'axios';
import React, { useEffect, useState } from 'react'
import { Link, useParams } from 'react-router-dom';
import '../Navbar/Singlepage.css'
const Singlepage = () => {
    const [data, setData] = useState([])
    const { product_id } = useParams();
    useEffect(() => {
        axios.get(`http://localhost:3000/Products?product_id=${product_id}`)
            .then((res) =>{
                setData(res.data[0])
                 console.log(res.data[0])}
            )
            .catch(() => {
                setData([])
            }
            )
    }, [])
  return (
    <div>
      {[data].map((ele)=>{return(<>
      <div id='marg'>
      <h4 id='cll'>Product Name:{ele.product_name}</h4>
      <hr></hr>
      <img src={ele.img_link} width={'400px'} height={'400px'} className='align'></img>
      <hr></hr>
      <div>
      <h5>Product category:{ele.category}</h5>
      <hr></hr>
      <h3 style={{color:'red'}}>Actual Price:{ele.actual_price}</h3>
      <hr></hr>
      <h3 style={{color:'green'}}>Discounted Price:{ele.discounted_price}</h3>
      <hr></hr>
      <h3 style={{color:'blue'}}>Percentage of discount:{ele.discount_percentage}</h3>
      <hr></hr>
      </div>
      <div id='kll'>
      <table>
        <tr><td ><Link id='buy'>BuyNow</Link></td>
        <td><Link id='add'>Add To Cart</Link></td></tr>
        </table> 
      </div>
      <div className='bxx'>
      <h4 style={{color:'purple'}}>About Product</h4>
      <hr></hr>
      <h6>{ele.about_product}</h6></div>
      <div className='tab'>
        <table>
        <tr><td>Rating:{ele.rating}</td>
        <td>Rating Count:{ele.rating_count}</td></tr>
        </table>
      </div>
      <div className='bxx'>
        <h4 style={{color:'purple'}}>Reviewers</h4>
        <hr></hr>
        <h6>{ele.user_name}</h6>
        <hr></hr>
        <h4 style={{color:'purple'}}>Reviews</h4>
        <hr></hr>
        <h6>{ele.review_id}</h6>
        <h6>{ele.review_title}</h6>
        <h6>{ele.review_content}</h6>
      </div>
      </div>
      </>
      )})}
    </div>
  )
}

export default Singlepage