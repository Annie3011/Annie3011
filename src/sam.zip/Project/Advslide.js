import React from 'react'
import Carousel from 'react-bootstrap/Carousel';
import purple from '../Project/Navbar/purple.avif';
import Social from '../Project/Navbar/Social.avif'
import gadgets from '../Project/Navbar/gadgets.jpg'
const Advslide = () => {
    return (
        <Carousel>
          <Carousel.Item>
          <img src={require("../Project/Navbar/Social.avif")} width={"1200px"} height={"550px"}></img>
            <Carousel.Caption>
            </Carousel.Caption>
          </Carousel.Item>
          <Carousel.Item>
          <img src={require("../Project/Navbar/purple.avif")}  width={"1200px"} height={"550px"}></img>
            <Carousel.Caption>
            </Carousel.Caption>
          </Carousel.Item>
          <Carousel.Item>
          <img src={require("../Project/Navbar/gadgets.jpg")} width={"1200px"} height={"550px"}></img>
            <Carousel.Caption>
            </Carousel.Caption>
          </Carousel.Item>
        </Carousel>
      );
}

export default Advslide